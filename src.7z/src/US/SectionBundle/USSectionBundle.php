<?php

namespace US\SectionBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class USSectionBundle extends Bundle
{
}
