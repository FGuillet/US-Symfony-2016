<?php

namespace US\CatalogBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\Form\FormInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Form\FormEvents;
use Symfony\Component\Form\FormEvent;

use US\CoreBundle\Form\ImageType;
use US\CatalogBundle\Entity\Category;
use US\CatalogBundle\Entity\ProductValue;

class EditProductType extends AbstractType
{
    /**
     * @param FormBuilderInterface $builder
     * @param array $options
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('name', 'text')
            ->add('description', 'textarea')
            ->add('idImage', 'hidden')
        ;

        $builder->add('type', 'entity', array(
                    'class' => 'USCatalogBundle:TypeProduct',
                    'choice_label' => 'name',
                    'multiple' => false,
                    'expanded' => false
                  ))
       ;

        $builder->add('values', 'collection', array(
                    'type' =>  new ProductValueType(),
                    'allow_add'    => true,
                    'allow_delete' => true,
                    'by_reference' => true,
                    'required' => true
                  ))
        ;

        $builder->add('save', 'submit');
    }

    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'US\CatalogBundle\Entity\Product'
        ));
    }

    /**
     * @return string
     */
    public function getName()
    {
        return 'us_catalogbundle_edit_product';
    }
}
