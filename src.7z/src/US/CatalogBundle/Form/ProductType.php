<?php

namespace US\CatalogBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\Form\FormInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Form\FormEvents;
use Symfony\Component\Form\FormEvent;

use US\CoreBundle\Form\ImageType;
use US\CatalogBundle\Entity\Category;

class ProductType extends AbstractType
{
    /**
     * @param FormBuilderInterface $builder
     * @param array $options
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('name', 'text')
            ->add('description', 'textarea')
            ->add('slug', 'text', array('required' => false))
            ->add('idImage', 'hidden')
            ->add('type', 'entity', array(
            'class' => 'USCatalogBundle:Category',
            'choice_label' => 'name',
            'multiple' => false,
            'expanded' => false
          ))
            ->add('save', 'submit')
        ;

        $formModifier = function (FormInterface $form, Category $typeProduct = null)
        {
            //$typeValues = null === $typeProduct ? array() : $typeProduct->getProperties();

            $form ->add('values', 'collection', array(
              'type' => new ProductValueType(),
              'allow_add' => true,
              'allow_delete' => true,
              'by_reference' => false,
              'required' => true
            ));
        };

        $builder->addEventListener(
            FormEvents::PRE_SET_DATA,
            function (FormEvent $event) use ($formModifier)
            {
                $form = $event->getForm();
                $product = $event->getData();

                if (null === $product)
                {
                  return;
                }

                $formModifier($event->getForm(), $product->getType());
            }
        );

        $builder->get('type')->addEventListener(
            FormEvents::POST_SUBMIT,
            function (FormEvent $event) use ($formModifier)
            {
                // It's important here to fetch $event->getForm()->getData(), as
                // $event->getData() will get you the client data (that is, the ID)
                $typeProduct = $event->getForm()->getData();

                // since we've added the listener to the child, we'll have to pass on
                // the parent to the callback functions!
                $formModifier($event->getForm()->getParent(), $typeProduct);
            }
        );
    }

    /**
     * @param OptionsResolverInterface $resolver
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'US\CatalogBundle\Entity\Product'
        ));
    }

    /**
     * @return string
     */
    public function getName()
    {
        return 'us_catalogbundle_product';
    }
}
