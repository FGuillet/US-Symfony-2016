<?php

namespace US\CatalogBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\Serializer\Serializer;
use Symfony\Component\Serializer\Encoder\JsonEncoder;
use Symfony\Component\Serializer\Normalizer\GetSetMethodNormalizer;
use Doctrine\Common\Collections\ArrayCollection;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Security;

use US\CatalogBundle\Entity\Product;
use US\CatalogBundle\Entity\Property;
use US\CatalogBundle\Entity\Category;
use US\CatalogBundle\Entity\ProductValue;
use US\CatalogBundle\Form\ProductType;
use US\CatalogBundle\Form\EditProductType;
use US\CatalogBundle\Form\PropertyType;
use US\CatalogBundle\Form\AddCategoryType;
use US\CatalogBundle\Form\PropertyNoSelectableType;

class CatalogController extends Controller
{
    // See all the categories which possess products
    public function indexAction()
    {
      $em = $this->getDoctrine()->getManager();

      $categories = $em
        ->getRepository('USCatalogBundle:Category')
        ->findCategoryWithImageAndProducts();

      $categoriesVisible = array();

      if ($categories !== null)
      {
        foreach ( $categories as $category )
        {
          if(count($category->getProducts()) > 0)
          {
            $categoriesVisible[] = $category;
          }
        }
      }

      return $this->render('USCatalogBundle:Catalog:index.html.twig', array(
          'categories' => $categoriesVisible
      ));
    }

    // See all the products in the backoffice
    public function indexManageAction()
    {
      $em = $this->getDoctrine()->getManager();

      $products = $em
        ->getRepository('USCatalogBundle:Product')
        ->findProductsWithCategory();

      return $this->render('USCatalogBundle:Manage:indexManage.html.twig', array(
          'products' => $products
      ));
    }

    // See all the categories in the backoffice
    public function indexCategoriesManageAction()
    {
      $em = $this->getDoctrine()->getManager();

      $categories = $em
        ->getRepository('USCatalogBundle:Category')
        ->findCategoriesWithProducts();

      return $this->render('USCatalogBundle:Manage:indexCategoriesManage.html.twig', array(
          'categories' => $categories
      ));
    }

    // See all the properties in the backoffice
    public function indexPropertiesManageAction()
    {
      $em = $this->getDoctrine()->getManager();

      $properties = $em
        ->getRepository('USCatalogBundle:Property')
        ->findAll();

      return $this->render('USCatalogBundle:Manage:indexPropertiesManage.html.twig', array(
          'properties' => $properties
      ));
    }

    // See product in the backoffice
    public function viewManageAction($id)
    {
        $em = $this->getDoctrine()->getManager();


        $product = $em
                      ->getRepository('USCatalogBundle:Product')
                      ->findProductWithId($id)
        ;

        if ($product === null)
        {
          throw new NotFoundHttpException('Ce produit n\'existe pas');
        }

        return $this->render('USCatalogBundle:Manage:viewManage.html.twig', array(
          'product' => $product
        ));
    }

    // See product
    public function viewAction($slug)
    {
        $em = $this->getDoctrine()->getManager();


        $product = $em
                      ->getRepository('USCatalogBundle:Product')
                      ->findProductWithSlug($slug)
        ;

        if ($product === null)
        {
          throw new NotFoundHttpException('Ce produit n\'existe pas');
        }

        return $this->render('USCatalogBundle:Catalog:view.html.twig', array(
          'product' => $product
        ));
    }

    // See property in the backoffice
    public function viewPropertyAction($id)
    {
        $em = $this->getDoctrine()->getManager();


        $property = $em
                      ->getRepository('USCatalogBundle:Property')
                      ->findPropertyWithValues($id)
        ;

        if ($property === null)
        {
          throw new NotFoundHttpException('Cette propriété n\'existe pas');
        }

        return $this->render('USCatalogBundle:Manage:viewPropertyManage.html.twig', array(
          'property' => $property
        ));
    }

    // See products according to the category
    public function viewProductsCategoryAction($slug)
    {
        $em = $this->getDoctrine()->getManager();


        $products = $em
          ->getRepository('USCatalogBundle:Product')
          ->findProductsAllWithCategory($slug)
        ;

        $category = $em
          ->getRepository('USCatalogBundle:Category')
          ->findCategoryBySlug($slug)
        ;

        if ($category === null)
        {
          throw new NotFoundHttpException('Cette catégorie n\'existe pas');
        }

        return $this->render('USCatalogBundle:Catalog:viewProductsCategory.html.twig', array(
          'products' => $products,
          'category' => $category
        ));
    }

    // See category in the backoffice
    public function viewCategoryAction($id)
    {
        $em = $this->getDoctrine()->getManager();


        $category = $em
          ->getRepository('USCatalogBundle:Category')
          ->getCategory($id);

        if ($category === null)
        {
          throw new NotFoundHttpException('Cette catégorie n\'existe pas');
        }

        return $this->render('USCatalogBundle:Manage:viewCategoryManage.html.twig', array(
          'category' => $category
        ));
    }

    // add product
    public function addAction(Request $request)
    {

        $em = $this->getDoctrine()->getManager();

        $product = new Product();

        $form = $this->createForm(new ProductType(), $product);

        if ($form->handleRequest($request)->isValid())
        {
          $values = $product->getValues();
          $productType = $product->getType();
          $idProductType = $productType->getId();
          $properties = $em
                          ->getRepository('USCatalogBundle:Category')
                          ->getCategory($idProductType)
                          ->getProperties()
          ;

          // For values in the product
          // Check the value and persist
          foreach ( $values as $key => $value )
          {

            if (is_array($value->getContent()))
            {
              $contents = $value->getContent();

              foreach ($contents as $content)
              {
                $productValue = $em
                                  ->getRepository('USCatalogBundle:ProductValue')
                                  ->find($content);

                $product->addValue($productValue);
              }

              $product->removeValue($value);
            }
            else
            {
              $value->setType($properties[$key]);
            }
          }

          if($product->getIdImage() !== null)
          {
            $image = $em
                        ->getRepository('USCoreBundle:Image')
                        ->find($product->getIdImage())
            ;

            if($image !== null)
            {
              $product->setimage($image);
            }
          }

          $em->persist($product);
          $em->flush();

          return $this->redirect($this->generateUrl('product_view_manage', array('id' => $product->getId())));

        }
        else
        {
          return $this->render('USCatalogBundle:Manage:addProductManage.html.twig', array(
                  'form' => $form->createView()
              ));

        }
    }


    // Ajax return all properties and values for the category in the product
    public function addPropertiesForProductAction(Request $request)
    {
      // Check is Ajax
      if($request->isXmlHttpRequest())
      {
          $em = $this->getDoctrine()->getManager();
          $id = $request->get('id');

          if ($id != null)
          {
            $typeProduct = $em
                         ->getRepository('USCatalogBundle:Category')
                         ->getCategory($id);

            $properties = $typeProduct->getProperties();

            // Create a table JSon
            $typeProductReturn = [ "name" => $typeProduct->getName() ];
            if(count($typeProduct->getProperties()) > 0)
            {
              $properties = $typeProduct->getProperties();
              foreach ($properties as $key => $property)
              {
                $typeProductReturn['properties'][$property->getId()] = [
                                                                          "name" => $property->getName(),
                                                                          "isSelectable" => $property->getIsSelectable()
                                                                       ];
                // If property add default values
                if($property->getIsSelectable() && count($property->getContents()) > 0)
                {

                  $values = $property->getContents();
                  foreach($values as $value)
                  {
                    $typeProductReturn['properties'][$property->getId()]['values'][$value->getId()] = $value->getContent();
                  }

                }
              }
            }

            return new JsonResponse($typeProductReturn);
          }

      }
    }

    // Add property
    public function addPropertyAction(Request $request)
    {
        $em = $this->getDoctrine()->getManager();

        $property = new Property();

        //$form = $this->createForm(new PropertyType(), $Property);
        $form = $this->createForm(new PropertyType(), $property);

        if ($form->handleRequest($request)->isValid())
        {
          $em = $this->getDoctrine()->getManager();

          $values = $property->getContents();

          // If propery add default values
          if(count($values) > 0)
          {
            $property->setIsSelectable(1);

            foreach ($values as $value)
            {
              $value->setType($property);
              $em->persist($value);
            }
          }


          $em->persist($property);
          $em->flush();

          $allValues = $request->get('us_catalogbundle_addproperty');

          return $this->render('USCatalogBundle:Catalog:test.html.twig', array());

          return $this->redirect($this->generateUrl('view_property', array('id' => $property->getId())));
        }

        return $this->render('USCatalogBundle:Manage:addPropertyManage.html.twig', array(
                'form' => $form->createView()
            ));
    }

    // Add category
    public function addCategoryAction(Request $request)
    {
        $em = $this->getDoctrine()->getManager();

        $category = new Category();

        $form = $this->createForm(new AddCategoryType(), $category);

        if ($form->handleRequest($request)->isValid())
        {
          if($category->getIdImage() !== null)
          {
            $image = $em
                        ->getRepository('USCoreBundle:Image')
                        ->find($news->getIdImage())
            ;

            if($image !== null)
            {
              $category->setImage($image);
            }
          }

          $em->persist($category);
          $em->flush();

          $request->getSession()->getFlashBag()->add('notice', 'Categorie bien enregistrée.');

          return $this->redirect($this->generateUrl('view_category', array('id' => $category->getId())));
        }

        return $this->render('USCatalogBundle:Manage:addCategoryManage.html.twig', array(
                'form' => $form->createView()
            ));
    }

    // NOT FINISH
    public function editAction($id, Request $request)
    {
        $em = $this->getDoctrine()->getManager();

        $product = $em
                      ->getRepository('USCatalogBundle:Product')
                      ->findProductWithId($id)
        ;

        $typeProduct = $product->getType();

        $properties = $em
                      ->getRepository('USCatalogBundle:Property')
                      ->getPropertiesWhereTypeProduct($typeProduct->getId())
        ;

        $form = $this->createForm(new ProductType(), $product);

        $oldValues = $product->getValues();

        $test = array();
        $test2 = '';

        if ($form->handleRequest($request)->isValid())
        {
          $productForm = $request->get('us_catalogbundle_product');
          $productValues = $request->get('us_catalogbundle_product')['values'];
          $values = $product->getValues()->getValues();
          //$product->removeAllValues();

          if (is_array($values))
          {
            foreach($values as $key => $productValue)
            {
              $content = $productValue->getContent();

              if(is_array($content))
              {

                $product->getValues()->remove($key);

                foreach($content as $value)
                {
                  $productValueInArray = $em
                                            ->getRepository('USCatalogBundle:ProductValue')
                                            ->find($value)
                  ;

                  $em->refresh($productValueInArray);

                  $product->addValue($productValueInArray);

                  $test[] = $productValueInArray;
                }

                $product->removeValue($productValue);
              }
              else
              {
                //$em->refresh($productValue);

                $em->persist($productValue);

                $test[] = $productValue;
              }
            }
          }

          $valuesAfter = $product->getValues();

          $em->persist($product);

          $valuesForm = $request->get('us_catalogbundle_product');

          //$em->flush();

          return $this->render('USCatalogBundle:Catalog:test.html.twig', array(
            'product' => $product,
            'test' => $test,
            'values' => $values,
            'valuesAfter' => $valuesAfter,
            'valuesForm' => $valuesForm,
            'productForm' => $productValues
          ));

          return $this->redirect($this->generateUrl('product_view', array('slug' => $product->getSlug())));

        }


      return $this->render('USCatalogBundle:Manage:editManage.html.twig', array(
      'form' => $form->createView(),
      'product' => $product,
      'properties' => $properties

      ));
    }

    // Edit property
    public function editPropertyAction($id, Request $request)
    {
        $em = $this->getDoctrine()->getManager();

        $property = $em
                      ->getRepository('USCatalogBundle:Property')
                      ->find($id)
        ;

        $selectable = $property->getIsSelectable();

        $oldValues = array();

        if ($selectable)
        {
          $form = $this->createForm(new PropertyType(), $property);
        }
        else
        {
          $form = $this->createForm(new PropertyNoSelectableType(), $property);
        }

        if ($form->handleRequest($request)->isValid())
        {
          $values = $property->getContents();

          if(count($values) > 0 && $property->getIsSelectable())
          {
            $oldValues = $em
                            ->getRepository('USCatalogBundle:ProductValue')
                            ->getProductValueWithProperty($id)
            ;

            $arrayValues = array();

            // Table of id send by form
            foreach ($values as $value)
            {
              $arrayValues[] = $value->getId();
            }

            // Check if $value is null
            foreach($oldValues as $value)
            {
              $inArray = array_search($value->getId(), $arrayValues);

              if($inArray == false)
              {
                $em->remove($value);
              }
            }

            // Check new $value
            foreach ($values as $value)
            {
              $value->setType($property);
              $em->persist($value);

            }
          }

          $em->persist($property);
          $em->flush();

          $allValues = $request->get('us_catalogbundle_property');

          return $this->redirect($this->generateUrl('property_index_manage'));

        }

        $listProperties = $em
                            ->getRepository('USCatalogBundle:Property')
                            ->findAll()
        ;



        return $this->render('USCatalogBundle:Manage:editPropertyManage.html.twig', array(
                'form'  =>  $form->createView(),
                'listProperties' => $listProperties,
                'property' => $property
            ));
    }

    // Edit category
    public function editCategoryAction($id, Request $request)
    {
        $em = $this->getDoctrine()->getManager();

        $category = $em
                      ->getRepository('USCatalogBundle:Category')
                      ->find($id)
        ;

        $properties = $category->getProperties();

        $idProperties = array();

        foreach ($properties as $property)
        {
          $idProperties[] = $property->getId();
        }

        $form = $this->createForm(new AddCategoryType(), $category);

        if ($form->handleRequest($request)->isValid())
        {

          $products = $em
                        ->getRepository('USCatalogBundle:Product')
                        ->findProductsWhereCategory($id)
          ;

          $propertiesForm = $category->getProperties();

          $idPropertiesForm = array();

          foreach ($propertiesForm as $propertyForm)
          {
            $idPropertiesForm[] = $propertyForm->getId();
          }

          $propertyIdForm = array();

          // Check if value delete, delete value in all products
          foreach($products as $product)
          {
            $productValues = $product->getValues();

            foreach ($productValues as $value)
            {
              $property = $value->getType();
              $idProperty = $property->getId();

              if (!in_array($idProperty, $idPropertiesForm))
              {
                  $em->remove($value);
              }
            }
          }

          $em->persist($category);
          $em->flush();
          return $this->redirect($this->generateUrl('view_category', array('id' => $id)));
        }

        return $this->render('USCatalogBundle:Manage:editCategoryManage.html.twig', array(
                'form'  =>  $form->createView(),
                'category' => $category
            ));
    }

    // Delete product
    public function deleteAction($id, Request $request)
    {
        $em = $this->getDoctrine()->getManager();

        $product = $em
                    ->getRepository('USCatalogBundle:Product')
                    ->find($id);

        $form = $this->createFormBuilder()->getForm();
        $request = $this->getRequest();

        if ($request->getMethod() == 'POST')
        {
          $form->bind($request);

          if ($form->isValid())
          {

            $values = $product->getValues();

            foreach ($values as $value)
            {
              $property = $value->getType();

              // If value is not default value, delete it
              if(!$property->getIsSelectable())
              {
                $em->remove($value);
              }
            }

            $em->remove($product);
            $em->flush();

            // Puis on redirige vers l'accueil
            return $this->redirect($this->generateUrl('product_index_manage'));
          }
        }

        return $this->render('USCatalogBundle:Manage:deleteManage.html.twig', array(
                'form' => $form->createView(),
                'product' => $product
            ));
    }

    // Delete category
    public function deleteCategoryAction($id, Request $request)
    {
        $em = $this->getDoctrine()->getManager();

        $category = $em
                    ->getRepository('USCatalogBundle:Category')
                    ->find($id)
        ;

        $form = $this->createFormBuilder()->getForm();
        $request = $this->getRequest();

        if ($request->getMethod() == 'POST')
        {
          $form->bind($request);

          if ($form->isValid())
          {
            $products = $em
                          ->getRepository('USCatalogBundle:Product')
                          ->findProductsWhereCategory($id)
            ;

            // Delete products of the category
            foreach($products as $product)
            {
              $em->remove($product);
            }

            $em->remove($category);
            $em->flush();

            // Puis on redirige vers l'accueil
            return $this->redirect($this->generateUrl('category_index_manage'));
          }
        }

        return $this->render('USCatalogBundle:Manage:deleteCategoryManage.html.twig', array(
                'form' => $form->createView(),
                'category' => $category
            ));
    }

    // Delete property
    public function deletePropertyAction($id, Request $request)
    {
        $em = $this->getDoctrine()->getManager();

        $property = $em
                    ->getRepository('USCatalogBundle:Property')
                    ->find($id)
        ;

        $form = $this->createFormBuilder()->getForm();
        $request = $this->getRequest();

        if ($request->getMethod() == 'POST')
        {
          $form->bind($request);

          if ($form->isValid())
          {
            $values = $em
                          ->getRepository('USCatalogBundle:ProductValue')
                          ->getProductValueWithProperty($id)
            ;

            // Delete value in property
            foreach($values as $value)
            {
              $em->remove($value);
            }

            $em->remove($property);
            $em->flush();

            // Puis on redirige vers l'accueil
            return $this->redirect($this->generateUrl('property_index_manage'));
          }
        }

        return $this->render('USCatalogBundle:Manage:deletePropertyManage.html.twig', array(
                'form' => $form->createView(),
                'property' => $property
            ));
    }



}
