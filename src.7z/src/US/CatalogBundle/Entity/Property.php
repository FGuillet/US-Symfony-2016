<?php

namespace US\CatalogBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Doctrine\Common\Collections\ArrayCollection;
use Symfony\Component\Validator\Constraints as Assert;

/**
 * TypeValue
 *
 * @ORM\Table(name="sf_property")
 * @ORM\Entity(repositoryClass="US\CatalogBundle\Entity\PropertyRepository")
 */
class Property
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="name", type="string", length=255)
     * @Assert\Length(min=5, minMessage="Le nom doit faire au moins {{ limit }} caractères.", max=255, maxMessage="Le nom ne doit pas faire plus de {{ limit }} caractères.")
     */
    private $name;

    /**
     * @ORM\ManyToMany(targetEntity="US\CatalogBundle\Entity\Category", mappedBy="properties")
     */
    private $typeProducts;

    /**
    * @ORM\OneToMany(targetEntity="US\CatalogBundle\Entity\ProductValue", mappedBy="type")
    */
    private $contents;

    /**
     * @var string
     *
     * @ORM\Column(name="is_selectable", type="boolean")
     */
    private $isSelectable = 0;

    /**
     * Constructor
     */
    public function __construct()
    {
        $this->typeProducts = new \Doctrine\Common\Collections\ArrayCollection();
        $this->contents = new \Doctrine\Common\Collections\ArrayCollection();
    }

    /**
     * Get id
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set name
     *
     * @param string $name
     * @return Property
     */
    public function setName($name)
    {
        $this->name = $name;

        return $this;
    }

    /**
     * Get name
     *
     * @return string
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * Add typeProducts
     *
     * @param \US\CatalogBundle\Entity\Category $typeProducts
     * @return Property
     */
    public function addTypeProduct(\US\CatalogBundle\Entity\Category $typeProduct)
    {
        $this->typeProducts[] = $typeProduct;

        return $this;
    }

    /**
     * Remove typeProducts
     *
     * @param \US\CatalogBundle\Entity\Category $typeProducts
     */
    public function removeTypeProduct(\US\CatalogBundle\Entity\Category $typeProduct)
    {
        $this->typeProducts->removeElement($typeProduct);
    }

    /**
     * Get typeProducts
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getTypeProducts()
    {
        return $this->typeProducts;
    }

    /**
     * Add contents
     *
     * @param \US\CatalogBundle\Entity\ProductValue $contents
     * @return Property
     */
    public function addContent(\US\CatalogBundle\Entity\ProductValue $content)
    {
        $this->contents[] = $content;

        return $this;
    }

    /**
     * Remove contents
     *
     * @param \US\CatalogBundle\Entity\ProductValue $contents
     */
    public function removeContent(\US\CatalogBundle\Entity\ProductValue $content)
    {
        $this->contents->removeElement($content);
    }

    /**
     * Get contents
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getContents()
    {
        return $this->contents;
    }

    /**
     * Set isSelectable
     *
     * @param string $isSelectable
     * @return Property
     */
    public function setIsSelectable($isSelectable)
    {
        $this->isSelectable = $isSelectable;

        return $this;
    }

    /**
     * Get isSelectable
     *
     * @return string
     */
    public function getIsSelectable()
    {
        return $this->isSelectable;
    }
}
