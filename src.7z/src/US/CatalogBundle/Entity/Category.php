<?php

namespace US\CatalogBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Doctrine\Common\Collections\ArrayCollection;
use Gedmo\Mapping\Annotation as Gedmo;
use Symfony\Component\Validator\Constraints as Assert;

/**
 * TypeProduct
 *
 * @ORM\Table(name="sf_category")
 * @ORM\Entity(repositoryClass="US\CatalogBundle\Entity\CategoryRepository")
 */
class Category
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="name", type="string", length=255, unique=true)
     * @Assert\Length(min=3, minMessage="Le nom doit faire au moins {{ limit }} caractères.", max=255, maxMessage="Le nom ne doit pas faire plus de {{ limit }} caractères.")
     */
    private $name;

    /**
     * @Gedmo\Slug(fields={"name"})
     * @ORM\Column(length=255, unique=true)
     */
    private $slug;

    /**
    * @ORM\ManyToOne(targetEntity="US\CoreBundle\Entity\Image", inversedBy="categories")
    */
    private $image;

    /**
     * @ORM\ManyToMany(targetEntity="US\CatalogBundle\Entity\Property", inversedBy="typeProducts", cascade={"persist"})
     */
    private $properties;

    /**
    * @ORM\OneToMany(targetEntity="US\CatalogBundle\Entity\Product", mappedBy="type")
    */
    private $products;

    /**
     * @var string
     */
    private $idImage;


    /**
     * Constructor
     */
    public function __construct()
    {
        $this->properties = new \Doctrine\Common\Collections\ArrayCollection();
        $this->products = new \Doctrine\Common\Collections\ArrayCollection();
    }

    /**
     * Get id
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set name
     *
     * @param string $name
     * @return TypeProduct
     */
    public function setName($name)
    {
        $this->name = $name;

        return $this;
    }

    /**
     * Get name
     *
     * @return string
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * Add properties
     *
     * @param \US\CatalogBundle\Entity\Property $properties
     * @return TypeProduct
     */
    public function addProperty(\US\CatalogBundle\Entity\Property $property)
    {
        $this->properties[] = $property;

        return $this;
    }

    /**
     * Remove properties
     *
     * @param \US\CatalogBundle\Entity\Property $properties
     */
    public function removeProperty(\US\CatalogBundle\Entity\Property $property)
    {
        $this->properties->removeElement($property);
    }

    /**
     * Get properties
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getProperties()
    {
        return $this->properties;
    }

    /**
     * Add products
     *
     * @param \US\CatalogBundle\Entity\Product $products
     * @return TypeProduct
     */
    public function addProduct(\US\CatalogBundle\Entity\Product $product)
    {
        $this->products[] = $product;

        return $this;
    }

    /**
     * Remove products
     *
     * @param \US\CatalogBundle\Entity\Product $products
     */
    public function removeProduct(\US\CatalogBundle\Entity\Product $product)
    {
        $this->products->removeElement($product);
    }

    /**
     * Get products
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getProducts()
    {
        return $this->products;
    }

    public function setIdImage($idImage)
    {
      $this->idImage = $idImage;

      return $this;
    }

    public function getIdImage()
    {
      return $this->idImage;
    }

    /**
     * Set image
     *
     * @param \US\CoreBundle\Entity\Image $image
     * @return Category
     */
    public function setImage(\US\CoreBundle\Entity\Image $image = null)
    {
        $this->image = $image;

        return $this;
    }

    /**
     * Get image
     *
     * @return \US\CoreBundle\Entity\Image
     */
    public function getImage()
    {
        return $this->image;
    }

    /**
     * Set slug
     *
     * @param string $slug
     * @return Category
     */
    public function setSlug($slug)
    {
        $this->slug = $slug;

        return $this;
    }

    /**
     * Get slug
     *
     * @return string
     */
    public function getSlug()
    {
        return $this->slug;
    }
}
