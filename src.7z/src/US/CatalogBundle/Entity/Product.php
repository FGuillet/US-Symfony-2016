<?php

namespace US\CatalogBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Gedmo\Mapping\Annotation as Gedmo;
use Symfony\Component\Validator\Constraints as Assert;

/**
 * Product
 *
 * @ORM\Table(name="sf_product")
 * @ORM\Entity(repositoryClass="US\CatalogBundle\Entity\ProductRepository")
 */
class Product
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="name", type="string", length=255)
     * @Assert\Length(min=3, minMessage="Le nom doit faire au moins {{ limit }} caractères.", max=255, maxMessage="Le nom ne doit pas faire plus de {{ limit }} caractères.")
     */
    private $name;

    /**
     * @var string
     *
     * @ORM\Column(name="description", type="text")
     * @Assert\NotNull()
     */
    private $description;

    /**
    * @ORM\ManyToOne(targetEntity="US\CatalogBundle\Entity\Category", inversedBy="products", cascade={"persist"})
    * @ORM\JoinColumn(nullable=false)
    */
    private $type;

    /**
    * @ORM\ManyToMany(targetEntity="US\CatalogBundle\Entity\ProductValue", inversedBy="products", cascade={"persist"})
    */
    private $values;

    /**
    * @ORM\ManyToOne(targetEntity="US\CoreBundle\Entity\Image", inversedBy="products", cascade={"persist"})
    * @ORM\JoinColumn(nullable=true)
    */
    private $image;

    /**
     * @Gedmo\Slug(fields={"name"})
     * @ORM\Column(length=128, unique=true)
     */
    private $slug;

    private $idImage;




    /**
     * Constructor
     */
    public function __construct()
    {
        $this->values = new \Doctrine\Common\Collections\ArrayCollection();
    }

    /**
     * Get id
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set name
     *
     * @param string $name
     * @return Product
     */
    public function setName($name)
    {
        $this->name = $name;

        return $this;
    }

    /**
     * Get name
     *
     * @return string
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * Set description
     *
     * @param string $description
     * @return Product
     */
    public function setDescription($description)
    {
        $this->description = $description;

        return $this;
    }

    /**
     * Get description
     *
     * @return string
     */
    public function getDescription()
    {
        return $this->description;
    }

    /**
     * Set type
     *
     * @param \US\CatalogBundle\Entity\Category $type
     * @return Product
     */
    public function setType(\US\CatalogBundle\Entity\Category $type)
    {
        $this->type = $type;

        return $this;
    }

    /**
     * Get type
     *
     * @return \US\CatalogBundle\Entity\Category
     */
    public function getType()
    {
        return $this->type;
    }

    /**
     * Add values
     *
     * @param \US\CatalogBundle\Entity\ProductValue $value
     * @return Product
     */
    public function addValue(\US\CatalogBundle\Entity\ProductValue $value)
    {
        $this->values[] = $value;

        return $this;
    }

    /**
     * Remove values
     *
     * @param \US\CatalogBundle\Entity\ProductValue $value
     */
    public function removeValue(\US\CatalogBundle\Entity\ProductValue $value)
    {
        $this->values->removeElement($value);
    }

    /**
     * Remove values
     */
    public function removeAllValues()
    {
        $this->values = '';
    }

    /**
     * Get values
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getValues()
    {
        return $this->values;
    }

    /**
     * Set image
     *
     * @param \US\CoreBundle\Entity\Image $image
     * @return Product
     */
    public function setImage(\US\CoreBundle\Entity\Image $image = null)
    {
        $this->image = $image;

        return $this;
    }

    /**
     * Get image
     *
     * @return \US\CoreBundle\Entity\Image
     */
    public function getImage()
    {
        return $this->image;
    }

    /**
     * Set slug
     *
     * @param string $slug
     * @return Product
     */
    public function setSlug($slug)
    {
        $this->slug = $slug;

        return $this;
    }

    /**
     * Get slug
     *
     * @return string
     */
    public function getSlug()
    {
        return $this->slug;
    }

    public function setIdImage($idImage)
    {
        $this->idImage = $idImage;

        return $this;
    }

    public function getIdImage()
    {
        return $this->idImage;
    }
}
