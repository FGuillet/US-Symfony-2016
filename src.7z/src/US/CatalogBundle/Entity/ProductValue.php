<?php

namespace US\CatalogBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Validator\Constraints as Assert;

/**
 * ProductValue
 *
 * @ORM\Table(name="sf_product_value")
 * @ORM\Entity(repositoryClass="US\CatalogBundle\Entity\ProductValueRepository")
 */
class ProductValue
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="content", type="text")
     * @Assert\NotNull()
     */
    private $content;

    /**
    * @var string
    *
    * @ORM\ManyToOne(targetEntity="US\CatalogBundle\Entity\Property", inversedBy="contents")
    * @ORM\JoinColumn(nullable=false)
    */
    private $type;

    /**
    * @ORM\ManyToMany(targetEntity="US\CatalogBundle\Entity\Product", mappedBy="values")
    * @ORM\JoinColumn(nullable=true)
    */
    private $products;






    public function __toString()
    {
      return array($this->type => $this->content);
    }
    /**
     * Constructor
     */
    public function __construct()
    {
        $this->products = new \Doctrine\Common\Collections\ArrayCollection();
    }

    /**
     * Get id
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set content
     *
     * @param string $content
     * @return ProductValue
     */
    public function setContent($content)
    {
        $this->content = $content;

        return $this;
    }

    /**
     * Get content
     *
     * @return string
     */
    public function getContent()
    {
        return $this->content;
    }

    /**
     * Set type
     *
     * @param \US\CatalogBundle\Entity\Property $type
     * @return ProductValue
     */
    public function setType(\US\CatalogBundle\Entity\Property $type)
    {
        $this->type = $type;

        return $this;
    }

    /**
     * Get type
     *
     * @return \US\CatalogBundle\Entity\Property
     */
    public function getType()
    {
        return $this->type;
    }

    /**
     * Add products
     *
     * @param \US\CatalogBundle\Entity\Product $products
     * @return ProductValue
     */
    public function addProduct(\US\CatalogBundle\Entity\Product $product)
    {
        $this->products[] = $product;

        return $this;
    }

    /**
     * Remove products
     *
     * @param \US\CatalogBundle\Entity\Product $products
     */
    public function removeProduct(\US\CatalogBundle\Entity\Product $product)
    {
        $this->products->removeElement($product);
    }

    /**
     * Get products
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getProducts()
    {
        return $this->products;
    }
}
