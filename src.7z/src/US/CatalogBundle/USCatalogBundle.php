<?php

namespace US\CatalogBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class USCatalogBundle extends Bundle
{
}
