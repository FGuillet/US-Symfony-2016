<?php

namespace US\NewsBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class USNewsBundle extends Bundle
{
}
